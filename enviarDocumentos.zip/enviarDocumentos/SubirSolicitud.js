document.addEventListener("DOMContentLoaded", function() {

    function enviarDocumento() {
        var matricula = document.getElementById("matricula").value;
        var fileInput = document.getElementById("file");
        var file = fileInput.files[0];

        if (matricula && file) {
            var reader = new FileReader();
            reader.onload = function(event) {
                var baseFile = event.target.result;
                localStorage.setItem(matricula, baseFile);
                alert("Archivo enviado y guardado con éxito.");
            };
            reader.readAsDataURL(file);
        } else {
            alert("Por favor, complete todos los campos.");
        }
    }

    function obtenerDocumento() {
        var matricula = document.getElementById("matricula").value;

        if (matricula) {
            var baseFile = localStorage.getItem(matricula);
            if (baseFile) {
                var link = document.createElement("a");
                link.href = baseFile;
                link.download = "Solicitud.pdf";
                link.click();
            } else {
                alert("No se encontró ningún documento para esta matrícula.");
            }
        } else {
            alert("Por favor, ingrese una matrícula.");
        }
    }

    document.getElementById("enviarBtn").addEventListener("click", enviarDocumento);
    document.getElementById("obtenerBtn").addEventListener("click", obtenerDocumento);
});
